jQuery(document).ready(function($) {
    // Frontend JavaScript functionality
    $('.wc-plan-customizer .plan-options').on('change', 'input, select', function() {
        // Handle plan option changes
    });
});